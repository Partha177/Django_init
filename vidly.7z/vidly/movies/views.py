from django.shortcuts import render, get_object_or_404
from django.http import Http404, HttpResponse
from .models import Movie

# Create your views here.


def index(request):
    movies = Movie.objects.all()  # DB Abstraction API
    # output = ', '.join([m.title for m in movies])
    # # SELECT * FROM movies_movie
    # # movies = Movie.objects.filter(release_year = 2022)
    # # SELECT * FROM movies_movie WHERE release_year=2022
    # # movies = Movie.object.get(id=1)   #returns 1 object
    # return HttpResponse(output)
    return render(request, 'movies/index.html', {'movies': movies})


def detail(request, movie_id):
    # try:
    #     movie = Movie.objects.get(pk=movie_id)
    #     # return HttpResponse(movie_id)
    #     return render(request, 'movies/detail.html', {'movie': movie})
    # except:
    #     raise Http404()
    movie = get_object_or_404(Movie, id=movie_id)
    return render(request, 'movies/detail.html', {'movie': movie})
